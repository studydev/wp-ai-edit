=== Hemtory AI Editor ===
Contributors: your-wp-org-username
Tags: ai, content, editor, gutenberg, openai, anthropic, claude
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 8.3
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Hemtory AI Editor – AI-powered content editing for the WordPress Gutenberg editor with Azure OpenAI, OpenAI (GPT-5.4), and Anthropic (Claude) models.

== Description ==

Hemtory AI Editor adds AI-powered editing capabilities directly into the Gutenberg block editor toolbar.

**AI Editing Actions:**

* **Your Command** – Give free-text instructions to the AI
* **Write More** – Continue writing with the same tone and style
* **My Style** – Rewrite text to match your personal writing style defined in the prompt
* **Highlight** – Mark key phrases and keywords with <mark> and <strong> tags
* **Summarize** – Condense long text into key points
* **Write Analogy** – Rewrite using metaphors and analogies
* **Fix Grammar** – Correct grammar, spelling, and punctuation
* **SEO Helper** – Analyze entire document to generate 3 recommended titles, 5 core keywords, and a 100-character summary

**Platform Features:**

* Real-time streaming AI responses (SSE)
* Gutenberg-compatible HTML output via configurable Tail Prompt
* Customizable system prompts per action with full prompt preview
* Tail Prompt appended to all actions (except SEO Helper) for consistent HTML formatting
* Works with single and multiple block selection
* API key encryption using libsodium
* Separate Azure OpenAI, OpenAI, and Anthropic tabs with independent API key, model, and pricing display

**Requirements:**

* Azure OpenAI API endpoint and key, OpenAI API key, or Anthropic API key (user-provided)

== Installation ==

1. Download `hemtory-ai-editor.zip` from the `releases/` directory
2. In WordPress admin, go to **Plugins → Add New → Upload Plugin** and upload the ZIP file
3. Activate the plugin
4. Go to **Hemtory AI Editor** in the admin menu
5. Use the LLM tabs to save settings for Azure OpenAI, OpenAI, or Anthropic
6. Click **Test Connection** to verify
7. Start editing with AI in the Gutenberg editor

**Reinstalling:** To reinstall or update, first **deactivate** the plugin and then **delete** it from the Plugins page. After that, upload and install the new ZIP file.

== Frequently Asked Questions ==

= What API do I need? =
You can use Azure OpenAI, OpenAI, or Anthropic. Azure OpenAI requires an endpoint and key. OpenAI and Anthropic require an API key only.

= Is my API key secure? =
Yes. API keys are encrypted using libsodium before storage.

= What is the Tail Prompt? =
The Tail Prompt is automatically appended to every system prompt (except SEO Helper) to instruct the AI to respond in Gutenberg-compatible HTML format. You can customize it in the admin settings.

= What does SEO Helper do? =
SEO Helper collects text from all blocks in the editor and asks the AI to generate 3 recommended titles, 5 core keywords, and a 100-character summary for the entire document.

= Can I preview the full prompt sent to the AI? =
Yes. Each prompt field in the admin settings has a "View Full Prompt" toggle that shows the system prompt combined with the Tail Prompt.

== Changelog ==

= 1.3.0 =
* Renamed plugin to Hemtory AI Editor
* Added AI image analysis: Describe Image, Suggest Caption, and custom image commands
* Image analysis results are inserted as a new paragraph below the image block
* Vision support for OpenAI/Azure (image_url) and Anthropic (base64)

= 1.2.0 =
* Added Anthropic (Claude) API support with Claude Opus 4.6, Sonnet 4.6, and Haiku 4.5 models
* Per-provider model tabs with pricing display (input/output per MTok)
* Azure OpenAI endpoint auto-appends /openai/v1 when entering a base resource URL
* Provider tabs now show logo icons (Azure, OpenAI, Anthropic)
* GPT-5.4 Pro selection prompts a cost confirmation dialog
* Admin settings redesigned with card layout and improved spacing
* Each provider saves its own endpoint, API key, and model independently

= 1.1.0 =
* Added My Style action (replaced Improve) – rewrite text in your personal style
* Added Highlight action – mark key phrases with HTML tags
* Added SEO Helper action – full-document SEO analysis
* Added Tail Prompt system – configurable response format instruction
* AI responses now return Gutenberg-compatible HTML
* Added full prompt preview with expand/collapse in admin settings
* Result popover now renders HTML content with styling

= 1.0.0 =
* Initial release

== Screenshots ==

1. AI toolbar button in the Gutenberg editor
2. Action menu with eight AI editing options
3. Real-time streaming AI response with HTML rendering
4. Admin settings page with prompt preview
5. Tail Prompt configuration section
6. SEO Helper analysis result